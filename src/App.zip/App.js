import { useState } from 'react';
import './App.css';
import NewQuestion from './component/NewQuestion/NewQuestion';
import Question from './component/Quiz/Question';
import Login from './component/Login/Login';
import { useEffect } from 'react';

const initquestions = [
  { id: 1, question: "What is full form of IT ?", option1: "Information Technology", option2: "Inform tech", option3: "Internal tech", option4: "All of the above" ,category:"general",correctAnswer:"Used For frontend"},
  { id: 2, question: "How much contry in word ?", option1: "200", option2: "300", option3: "276 ", option4: "none of the this",category:"general",correctAnswer:"All of the above" },
  { id: 3, question: "What is JavaScript", option1: "WebProgramming", option2: "backendprogramming", option3: "None Of the Above", option4: "Framework",category:"technical",correctAnswer:"None Of the Above" },
  { id: 4, question: "What is Java", option1: "Used For webdevelopment", option2: "use for car making", option3: "software development ", option4: "All of the above",category:"technical",correctAnswer:"Used For webdevelopment" }];

  
function App() {

  const[question,setquestion]=useState(initquestions);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  


  const addquestionhandler = (question) => 
  {
    console.log(question);
    setquestion((prevState) => 
    { 
      return [question, ...prevState];
    });
    };

  //   useEffect(()=>{
  //     const username = localStorage.getItem("email");
  //     if(username==="pankaj@gmail.com")
  //     {
  //       setIsLoggedIn(true)
  //     }
  // },[])

   useEffect(()=>{
      localStorage.setItem("id",1);
      localStorage.setItem("email","pankaj@gmail.com");
      localStorage.setItem("password","123");
      localStorage.setItem("Role","Trainer")
},[])

    const loginHandler = (email, password) => {

      if(email==="pankaj@gmail.com" && password==="123")
    {
      setIsLoggedIn(true);
    }
    else{
      setIsLoggedIn(false)
    }
     
    };

    const logoutHandler = () => {
      localStorage.removeItem("id",1);
      localStorage.removeItem("email","pankaj@gmail.com");
      localStorage.removeItem("password","123");
      localStorage.removeItem("Role","Trainer")
      setIsLoggedIn(false);
    };

  return (
    <div className="App">
      <h1>Login to System to Use Quize App</h1>
      {!isLoggedIn && <Login onLogin={loginHandler} />}
      
     {isLoggedIn && <NewQuestion addquestion={addquestionhandler}  onLogout={logoutHandler}/>}
     <Question question={question}/>
    </div>
  );
}

export default App;
