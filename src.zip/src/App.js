import { useState } from 'react';
import './App.css';
import NewQuestion from './component/NewQuestion/NewQuestion';
import Question from './component/Quiz/Question';
import Login from './component/Login/Login';
import { useEffect } from 'react';

const initquestions = [
  { id: 1, question: "What is full form of IT ?", option1: "Information Technology", option2: "Inform tech", option3: "Internal tech", option4: "All of the above" ,category:"general",correctAnswer:"Used For frontend"},
  { id: 2, question: "How much contry in word ?", option1: "200", option2: "300", option3: "276 ", option4: "none of the this",category:"general",correctAnswer:"All of the above" },
  { id: 3, question: "What is JavaScript", option1: "WebProgramming", option2: "backendprogramming", option3: "None Of the Above", option4: "Framework",category:"technical",correctAnswer:"None Of the Above" },
  { id: 4, question: "What is Java", option1: "Used For webdevelopment", option2: "use for car making", option3: "software development ", option4: "All of the above",category:"technical",correctAnswer:"Used For webdevelopment" }
];

  
function App() {

  const[question,setquestion]=useState(initquestions);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userisLoggedIn, setuserIsLoggedIn] = useState(false);
  

  const addquestionhandler = (question) => 
  {
    console.log(question);
    setquestion((prevState) => 
    { 
      return [question, ...prevState];
    });
    };

    useEffect(()=>{
      const username = localStorage.getItem("email");
      if(username==="pankaj@gmail.com")
      {
        setIsLoggedIn(true)
      }

  },[])

  useEffect(()=>{
    const username = localStorage.getItem("email");
    if(username==="aman@gmail.com")
    {
      setIsLoggedIn(true)
    }

},[])

useEffect(()=>{
      localStorage.setItem("email","pankaj@gmail.com")
      localStorage.setItem("password","123")
      localStorage.setItem("name","pankaj");
      localStorage.setItem("Role","Trainer")

},[])



    const loginHandler = (email, password) => {
      //trainer
      
    if(email==="pankaj@gmail.com" && password==="123")
    {
      localStorage.setItem("email","pankaj@gmail.com")
      localStorage.setItem("password","123")
      localStorage.setItem("name","pankaj");
      localStorage.setItem("Role","Trainer")

      setIsLoggedIn(true);
    }
   else if(email==="aman@gmail.com" && password==="123")
   {
      localStorage.setItem("email","aman@gmail.com")
      localStorage.setItem("password","123")
      localStorage.setItem("name","aman");
      localStorage.setItem("Role","Trainee")

     setuserIsLoggedIn(true);
   }

    else{

      setIsLoggedIn(false)
      setuserIsLoggedIn(false);
    }

    };

    const logoutHandler = () => {
      localStorage.removeItem("id",1);
      localStorage.removeItem("email","pankaj@gmail.com");
      localStorage.removeItem("password","123");
      localStorage.removeItem("name","pankaj");
      localStorage.removeItem("Role","Trainer")
      setIsLoggedIn(false);

    };
    const userlogoutHandler = () => {
      localStorage.removeItem("id",2);
      localStorage.removeItem("email","aman@gmail.com");
      localStorage.removeItem("password","123");
      localStorage.removeItem("name","aman");
      localStorage.removeItem("Role","Trainee")
      setIsLoggedIn(false);

    };

  return (
    <div className="App">
      <h1>Login to System to Use Quize App</h1>
      {!isLoggedIn && !userisLoggedIn&& <Login onLogin={loginHandler} />}
      
     {isLoggedIn && <NewQuestion addquestion={addquestionhandler}  onLogout={userlogoutHandler}/> }
     {isLoggedIn && <Question question={question}/> }
     {userisLoggedIn && <Question question={question} onLogout={logoutHandler}/>}
     {/* <Question question={question}/> */}
    </div>
  );
}

export default App;
